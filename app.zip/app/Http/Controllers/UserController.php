<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Testimonial;
class UserController extends Controller
{
    public function index(){
        
        $products = Product::all();
        $testimonials = Testimonial::all();
        // dd($product);
        //         "id" => 7
        // "name" => "coco"
        // "price" => 200
        // "discount" => 40
        // "pic" => "photo-1526947425960-945c6e72858f.jpeg"
        // "weight" => "90"
        // "description" => "Good Oil"
        // "description2" => null
        // "category" => null
        // "quantity" => 12
        // "status" => "0"
        // "created_at" => "2021-09-14 07:01:53"
        // "updated_at" => "2021-09-14 07:02:49"
        
        //       "id" => 3
        // "name" => "Lokesh"
        // "pic" => "passpost-size-lokesh.png"
        // "message" => "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s"
        // "created_at" => "2021-09-14 13:48:55"
        // "updated_at" => "2021-09-14 13:48:55"
        return view('index2',['products' => $products,'testimonials' => $testimonials]);
    }
}

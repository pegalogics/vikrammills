@extends('layouts.master')

@section('title',
  'Login')

@section('content')
  @include('inc.user.pageContent.indexContent')
@endsection

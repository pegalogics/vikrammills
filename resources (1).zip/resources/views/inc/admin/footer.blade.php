    <!-- /.content-wrapper -->
  <footer class="main-footer">
    <small>Copyright &copy; 2019-<?php echo date('Y'); ?></small>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <small>Version 1.1.0</small>
    </div>
  </footer>

</div>
<!-- ./wrapper -->
@include('inc/admin/jsGlobal')

</body>
</html>

@include('inc/admin/header')

@include('inc/admin/sidebar')

<!-- Content Area Starts-->
@yield('content')    
<!-- Content Area Ends-->      
      
@include('inc/admin/footer')
<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class OrderReturnControllersTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('order_return_controllers')->delete();
        
        
        
    }
}
@extends('layouts.masterAdmin')
@section('content')
  @include('inc/admin/testimonialContent')
@endsection
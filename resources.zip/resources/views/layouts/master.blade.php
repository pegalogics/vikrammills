
<html class="no-js"
      lang="zxx">
    @include('inc/user/head')
    <body>
        @yield('header')
        @yield('content')
        @yield('footer')
        @include('inc/user/script')
    </body>
</html>


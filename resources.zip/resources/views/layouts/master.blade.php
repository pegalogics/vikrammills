
<html class="no-js"
      lang="zxx">
    @include('inc/user/head')
    <body>
        @include("inc.user.Header")
        @yield('content')
        @include("inc.user.footer")
        @include('inc/user/script')
    </body>
</html>


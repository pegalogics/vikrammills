@extends('layouts.masterAdmin')
@section('content')
  @include('inc/admin/productsContent')
@endsection
@extends('layouts.masterAdmin')
@section('content')
  @include('inc/admin/orderAnnouncement')
@endsection
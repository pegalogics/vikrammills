@extends('layouts.masterAdmin')
@section('content')
  @include('inc/admin/categoryContent')
@endsection
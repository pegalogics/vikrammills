<div>
    <div class="alert alert-{{ $type }}">
        {{ $message }}
    </div>
</div>
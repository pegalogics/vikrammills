    <!-- ABOUT US AREA START -->
    <div class="ltn__about-us-area pt-30-- pb-120 col-lg-12">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-6 align-self-center">
                    <div class="about-us-info-wrap pt-30 pb-30 ">
<center>   <img src="images/blog.jpg" alt="">  </center><br>
<br>
<br>
<br>
</div>
                </div>
				    
				 
			
                <!--<div class="col-lg-3 col-md-6 align-self-center">
                    <div class="about-us-img-wrap about-img-right">
                        <img src="img/bg/about1.jpg" alt="Banner Image" style="height: 400px; width: 500px !important;">
                    </div>
                </div>-->
            </div>
        </div>
    </div>
    <!-- ABOUT US AREA END -->
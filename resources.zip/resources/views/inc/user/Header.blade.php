        <header
                class="ltn__header-area ltn__header-4 ltn__header-6 ltn__header-transparent--- gradient-color-2---">
          <!-- ltn__header-top-area start -->
          <div
               class="ltn__header-top-area top-area-color-white">
            <div
                 class="container">
              <div
                   class="row">
                <div
                     class="col-md-7">
                  <div
                       class="ltn__top-bar-menu">

                  </div>
                </div>
                <div
                     class="col-md-5">
                  <div
                       class="top-bar-right text-right">
                    <div
                         class="ltn__top-bar-menu">
                      <ul>
                        <li>
                          <!-- ltn__language-menu -->
                          <div
                               class="ltn__drop-menu ltn__currency-menu ltn__language-menu">
                            <ul>
                              <li>
                                <a href="#"
                                   class="dropdown-toggle"><span
                                        class="active">English</span></a>
                                <ul>
                                  <li>
                                    <a
                                       href="#">Hindi</a>
                                  </li>
                                  <li>
                                    <a
                                       href="#">Bengali</a>
                                  </li>
                                  <li>
                                    <a
                                       href="#">Panjabi</a>
                                  </li>
                                  <li>
                                    <a
                                       href="#">Tamil</a>
                                  </li>
                                  <li>
                                    <a
                                       href="#">Marathi</a>
                                  </li>

                                </ul>
                              </li>

                            </ul>
                          </div>
                        </li>
                        <li>
                          <!-- ltn__language-menu -->
                          <div
                               class="ltn__drop-menu ltn__currency-menu ltn__language-menu">
                            <ul>
                              <li
                                  style="top: 42px;">
                                <form class="search"
                                      action="#">
                                  <input type="text"
                                         placeholder="Search.."
                                         name="search2">
                                  <button
                                          type="submit"><i
                                       class="fa fa-search"></i></button>
                                </form>
                              </li>

                            </ul>
                          </div>
                        </li>

                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- ltn__header-top-area end -->

          <!-- ltn__header-middle-area start -->
          <div class="ltn__header-middle-area ltn__header-sticky ltn__sticky-bg-black"
               style=" background-color: rgba(247, 201, 157, 1); ">
            <div
                 class="container">
              <div
                   class="row">
                <div
                     class="col col-lg-2">
                  <div
                       class="site-logo">
                    <a
                       href={{url('index')}}><img
                           src="images/logo.png"
                           alt="Logo"></a>
                  </div>
                </div>
                <div
                     class="col-lg-6 col">
                  <div class="header-search-wrap"
                       style="margin-top: 25px;">
                    <div>

                      <form class="example"
                            action="#"
                            style="margin:auto;max-width:550px">
                        <input type="text"
                               placeholder="Search.."
                               name="search2">
                        <button
                                type="submit"><i
                             class="fa fa-search"></i></button>
                      </form>

                      <!--<form>
      <input type="text" placeholder="Search.." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>-->
                      <!--<input type="text" name="search" value="" placeholder="Search here" class=""/> 
									<button type="submit"><i class="fa fa-search"></i></button>-->
                    </div>

                  </div>

                </div>

                <div
                     class="col-lg-4 col header-menu-column menu-color-white---">
                  <div
                       class="header-menu d-none d-xl-block">
                    <nav>
                      <div
                           class="ltn__main-menu">

                        <ul>

                          <li>
                            <a
                               href="index-2.html">Home</a>
                          </li>
                          <li
                              class="menu-icon">
                            <a
                               href="product.html">Product</a>
                            <ul
                                class="mega-menu">
                              <li>
                                <div
                                     class="menu-product-item">
                                  <div
                                       class="menu-product-img">
                                    <a
                                       href="#"><img
                                           src="images/tanduri.png"
                                           alt="#"></a>
                                  </div>
                                  <div
                                       class="product-info">
                                    <h2
                                        class="product-title">
                                      <a
                                         href="#">Tanduri
                                        Atta</a>
                                    </h2>
                                    <div
                                         class="product-price">
                                      <span>&#x20B9;
                                        350</span>
                                      <del>&#x20B9;400</del>
                                    </div>
                                  </div>
                                </div>
                              </li>
                              <li>
                                <div
                                     class="menu-product-item">
                                  <div
                                       class="menu-product-img">
                                    <a
                                       href="#"><img
                                           src="images/product4.webp"
                                           alt="#"></a>
                                  </div>
                                  <div
                                       class="product-info">
                                    <h2
                                        class="product-title">
                                      <a
                                         href="#">Maida
                                        500g
                                        |
                                        50Kg</a>
                                    </h2>
                                    <div
                                         class="product-price">
                                      <span>&#x20B9;
                                        350</span>
                                      <del>&#x20B9;400</del>
                                    </div>
                                  </div>
                                </div>
                              </li>
                              <li>
                                <div
                                     class="menu-product-item">
                                  <div
                                       class="menu-product-img">
                                    <a
                                       href="#"><img
                                           src="images/product3.webp"
                                           alt="#"></a>
                                  </div>
                                  <div
                                       class="product-info">
                                    <h2
                                        class="product-title">
                                      <a
                                         href="#">Sooji
                                        500g
                                        |
                                        50Kg</a>
                                    </h2>
                                    <div
                                         class="product-price">
                                      <span>&#x20B9;
                                        350</span>
                                      <del>&#x20B9;400</del>
                                    </div>
                                  </div>
                                </div>
                              </li>
                              <li>
                                <div
                                     class="menu-product-item">
                                  <div
                                       class="menu-product-img">
                                    <a
                                       href="#"><img
                                           src="images/product2.webp"
                                           alt="#"></a>
                                  </div>
                                  <div
                                       class="product-info">
                                    <h2
                                        class="product-title">
                                      <a
                                         href="#">Dalia
                                        500g
                                        |
                                        50Kg</a>
                                    </h2>
                                    <div
                                         class="product-price">
                                      <span>&#x20B9;
                                        350</span>
                                      <del>&#x20B9;400</del>
                                    </div>
                                  </div>
                                </div>
                              </li>
                              <li>
                                <div
                                     class="menu-product-item">
                                  <div
                                       class="menu-product-img">
                                    <a
                                       href="#"><img
                                           src="images/product1.webp"
                                           alt="#"></a>
                                  </div>
                                  <div
                                       class="product-info">
                                    <h2
                                        class="product-title">
                                      <a
                                         href="#">Rawa
                                        500g
                                        |
                                        50Kg</a>
                                    </h2>
                                    <div
                                         class="product-price">
                                      <span>&#x20B9;
                                        350</span>
                                      <del>&#x20B9;400</del>
                                    </div>
                                  </div>
                                </div>
                              </li>
                              <li>
                                <div
                                     class="menu-product-item">
                                  <div
                                       class="menu-product-img">
                                    <a
                                       href="#"><img
                                           src="images/fresh-cakki.webp"
                                           alt="#"></a>
                                  </div>
                                  <div
                                       class="product-info">
                                    <h2
                                        class="product-title">
                                      <a
                                         href="#">Chakki
                                        Atta
                                        10kg
                                        |
                                        50kg</a>
                                    </h2>
                                    <div
                                         class="product-price">
                                      <span>&#x20B9;
                                        350</span>
                                      <del>&#x20B9;400</del>
                                    </div>
                                  </div>
                                </div>
                              </li>
                              <li>
                                <div
                                     class="menu-product-item">
                                  <div
                                       class="menu-product-img">
                                    <a
                                       href="#"><img
                                           src="images/bran.png"
                                           alt="#"></a>
                                  </div>
                                  <div
                                       class="product-info">
                                    <h2
                                        class="product-title">
                                      <a
                                         href="#">India
                                        Gate
                                        Bran
                                        49
                                        Kg</a>
                                    </h2>
                                    <div
                                         class="product-price">
                                      <span>&#x20B9;
                                        350</span>
                                      <del>&#x20B9;400</del>
                                    </div>
                                  </div>
                                </div>
                              </li>

                            </ul>
                          </li>
                          <li>
                            <a
                               href="recipe.html">Recipe</a>
                          </li>

                          @if (!Session::has('user'))
                            <li>
                              <a
                                 href={{ url('login') }}>Log
                                In
                                /
                                Register</a>
                            <li>
                            @else

                              <a
                                 href="#">{{ Session::get('user')->name }}
                              </a>
                              <a
                                 href={{ url('logout') }}>Logout</a>


                          @endif

                          </li>
                          <li>
                            <a href="cart.html"
                               title="Shoping Cart">
                              <span
                                    class="utilize-btn-icon">
                                <i
                                   class="fas fa-shopping-cart"></i>

                              </span>
                            </a>
                          </li>
                        </ul>
                      </div>
                    </nav>
                  </div>
                </div>

                <div
                     class="col col-lg-2">
                  <div
                       class="ltn__header-options ltn__header-options-color-white----">


                    <!-- header-search-1 -->


                    <!-- Mobile Menu Button -->
                    <div
                         class="mobile-menu-toggle d-xl-none">
                      <a href="#ltn__utilize-mobile-menu"
                         class="ltn__utilize-toggle">
                        <svg
                             viewBox="0 0 800 600">
                          <path d="M300,220 C300,220 520,220 540,220 C740,220 640,540 520,420 C440,340 300,200 300,200"
                                id="top">
                          </path>
                          <path d="M300,320 L540,320"
                                id="middle">
                          </path>
                          <path d="M300,210 C300,210 520,210 540,210 C740,210 640,530 520,410 C440,330 300,190 300,190"
                                id="bottom"
                                transform="translate(480, 320) scale(1, -1) translate(-480, -318) ">
                          </path>
                        </svg>
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- ltn__header-middle-area end -->
        </header>

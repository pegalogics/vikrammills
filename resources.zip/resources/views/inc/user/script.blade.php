  <!-- All JS Plugins -->
  <script
          src="js/plugins.js">
  </script>
  <!-- Main JS -->
  <script
          src="js/main.js">
  </script>

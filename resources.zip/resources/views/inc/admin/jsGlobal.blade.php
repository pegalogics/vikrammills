<!--begin::Global Javascript Bundle(used by all pages)-->
<script src={{asset("assets_admin/plugins/global/plugins.bundle.js")}}></script>
<script src={{asset("assets_admin/js/scripts.bundle.js")}}></script>
<!--end::Global Javascript Bundle-->
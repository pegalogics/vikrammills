<base href="">
<meta charset="utf-8" />
<title>Pegalogics</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<!--begin::Fonts-->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
<!--end::Fonts-->
<!--begin::Global Stylesheets Bundle(used by all pages)-->
<link href={{asset("assets_admin/plugins/global/plugins.bundle.css")}} rel="stylesheet" type="text/css" />
<link href={{asset("assets_admin/css/style.bundle.css")}} rel="stylesheet" type="text/css" />
<!--end::Global Stylesheets Bundle-->

<!-- Bootstrap -->
<!-- Latest compiled and minified CSS -->